<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kapcsolatfelveto";

// Kapcsolódás az adatbázishoz
$conn = new mysqli($servername, $username, $password, $dbname);

// Ellenőrizzük a kapcsolatot
if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}

// Az űrlap adatai
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// SQL lekérdezés az adatbázisba való beszúráshoz (prepare statement)
$stmt = $conn->prepare("INSERT INTO reports (name, email, message) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $message);

if ($stmt->execute()) {
    echo "<h2 style='text-align:center; color: #FFD700;'>Az üzenet sikeresen elküldve!</h2>";
} else {
    echo "Hiba történt: " . $stmt->error;
}

// Kapcsolat bezárása
$stmt->close();
$conn->close();
?>